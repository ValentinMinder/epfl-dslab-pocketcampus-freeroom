PopupMenuCompat
===============

A narrow-gauged compatibility for Android's Holo-Widget "PopupMenu".

On pre-Honeycomb devices an AlertDialog will be shown - instead of the PopupMenu. This library works with Android 1.6 or higher.

The project provides an example activity.
