/**************************************************************************
 * copyright file="IDateTimePropertyDefinition.java" company="Microsoft"
 *     Copyright (c) Microsoft Corporation.  All rights reserved.
 * 
 * Defines the IDateTimePropertyDefinition.java.
 **************************************************************************/
package microsoft.exchange.webservices.data;

/**
 * The Interface DateTimePropertyDefinitionInterface.
 */
 interface IDateTimePropertyDefinition {

}